#include<iostream>
using namespace std;
int main(){
    int a=20;
    if(a&1){
        cout<<"odd"<<endl;
    }
    else{
        cout<<"even";
    }
    return 0;
    
}